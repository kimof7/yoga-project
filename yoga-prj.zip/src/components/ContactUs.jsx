import React from 'react'
import Footer from './Footer'
import TopHeader from './TopHeader'

const ContactUs = () => {
  return (
    <>
    <TopHeader>ContactUs</TopHeader>
    <Footer /> 
    </>)
}

export default ContactUs